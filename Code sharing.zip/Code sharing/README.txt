Author - David Foster
Created 11/29/2025

Purpose:
Creates a tool that merges a CSV data set to a feature class shapefile created from a JSON file.

Data used:
Iowa 2020 Census Data - Percent of limited English-speaking households per Story County Census Tract